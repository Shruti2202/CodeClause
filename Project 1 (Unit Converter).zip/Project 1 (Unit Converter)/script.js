function convert() {
    var inputValue = parseFloat(document.getElementById("inputValue").value);
    var fromUnit = document.getElementById("fromUnit").value;
    var toUnit = document.getElementById("toUnit").value;
    var result = 0;
  
    // Conversion logic
    if (fromUnit === "meter" && toUnit === "centimeter") {
      result = inputValue * 100;
    } else if (fromUnit === "meter" && toUnit === "inch") {
      result = inputValue * 39.37;
    } else if (fromUnit === "centimeter" && toUnit === "meter") {
      result = inputValue / 100;
    } else if (fromUnit === "centimeter" && toUnit === "inch") {
      result = inputValue / 2.54;
    } else if (fromUnit === "inch" && toUnit === "meter") {
      result = inputValue / 39.37;
    } else if (fromUnit === "inch" && toUnit === "centimeter") {
      result = inputValue * 2.54;
    } else {
      result = inputValue;
    }
  
    document.getElementById("result").value = result.toFixed(2);
  }
  